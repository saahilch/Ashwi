namespace productcrud.Repository;
using productcrud.Entities;
using MySql.Data.MySqlClient;

public class MySqlDBManager{
    
    public List<Product> GetAllProd(){
        List<Product> products=new List<Product>();
        MySqlConnection con=new MySqlConnection();
        con.ConnectionString=@"port=3306;host=localhost;user=root;password=root123;database=dotnet";
        MySqlCommand cmd=new MySqlCommand();
        cmd.CommandText="select * from product";
        cmd.Connection=con;
        try{
            con.Open();
            MySqlDataReader reader=cmd.ExecuteReader();
            while(reader.Read()){
                int id=int.Parse(reader["id"].ToString());
                string? name=reader["name"].ToString();
                float price=float.Parse(reader["price"].ToString());
                int qty=int.Parse(reader["quantity"].ToString());

                Product p=new Product();

                p.Id=id;
                p.Name=name;
                p.Price=price;
                p.Quantity=qty;
                products.Add(p);
            }
        }
        catch(Exception e){
            Console.WriteLine(e);
        }
        finally{
            con.Close();
        }
        return products;
    }

     public Product GetById(int id){
        
        Product p=new Product();
        MySqlConnection con=new MySqlConnection();
        con.ConnectionString=@"port=3306;host=localhost;user=root;password=root123;database=dotnet";
        MySqlCommand cmd=new MySqlCommand();
        cmd.CommandText="select * from product where id="+id;
        cmd.Connection=con;
        try{
            con.Open();
            MySqlDataReader reader=cmd.ExecuteReader();
            if(reader.Read()){
                int prodid=int.Parse(reader["id"].ToString());
                string? name=reader["name"].ToString();
                float price=float.Parse(reader["price"].ToString());
                int qty=int.Parse(reader["quantity"].ToString());


                p.Id=prodid;
                p.Name=name;
                p.Price=price;
                p.Quantity=qty;
            }
            reader.Close();
        }
        catch(Exception e){
            Console.WriteLine(e);
        }
        finally{
            con.Close();
        }
        return p;
    }

    public void Delete(int id){
        
        Product p=new Product();
        MySqlConnection con=new MySqlConnection();
        con.ConnectionString=@"port=3306;host=localhost;user=root;password=root123;database=dotnet";
        MySqlCommand cmd=new MySqlCommand();
        cmd.CommandText="delete from product where id="+id;
        cmd.Connection=con;
        try{
            con.Open();
            cmd.ExecuteNonQuery();
        }
        catch(Exception e){
            Console.WriteLine(e);
        }
        finally{
            con.Close();
        }
    }

    public void Insert(Product prod){
        
        MySqlConnection con=new MySqlConnection();
        con.ConnectionString=@"port=3306;host=localhost;user=root;password=root123;database=dotnet";
        MySqlCommand cmd=new MySqlCommand();
        cmd.CommandText="insert into product values('"+prod.Id+"','"+prod.Name+"','"+prod.Price+"','"+prod.Quantity+"')";
        cmd.Connection=con;
        try{
            con.Open();
            cmd.ExecuteNonQuery();
        }
        catch(Exception e){
            Console.WriteLine(e);
        }
        finally{
            con.Close();
        }
    }
}
